# Resume Website

## Basics

Uses HTML5, CSS, and JavaScript for theme and splash screen on load animation.

## To-Do's

- Add links to LinkedIn, Github, ??
- Make a projects tab that includes everything from my Workday profile, professionally worded
- Add images
- Try to add a reveal-on-hover option for certain text or buttons

=======

## Testing

1. Install dependencies (only required the first time):
   ```bash
   npm install
   ```
2. Run the test suite with:
   ```bash
   npm test
   ```

